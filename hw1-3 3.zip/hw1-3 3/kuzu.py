# kuzu.py
# COMP9444, CSE, UNSW

from __future__ import print_function
import torch
import torch.nn as nn
import torch.nn.functional as F

class NetLin(nn.Module):
    # linear function followed by log_softmax
    def __init__(self):
        super(NetLin, self).__init__()
        # INSERT CODE HERE
        #creating linear function
        self.linearfunc1=nn.Linear(784, 10)

    def forward(self, x):
         # CHANGE CODE HERE
       
         #to flatten the input
         x = x.view(x.shape[0], -1)
        
         
         
         #activating linear function
         x=self.linearfunc1(x)
         
         
         #activating log softmax
         x = F.log_softmax(x, dim=1)
        
         return x

class NetFull(nn.Module):
    # two fully connected tanh layers followed by log softmax
    def __init__(self):
        super(NetFull, self).__init__()
        # INSERT CODE HERE
        #creating linear function
        self.linearfunc1=nn.Linear(784,150)
        #creating linear function
        self.linearfunc2=nn.Linear(150,10)

    def forward(self, x):
        # CHANGE CODE HERE
        #flattening the input
        x = x.view(x.shape[0], -1)
        
        #activating linear function
        x = self.linearfunc1(x)
        
        
        #activate tanh
        x = torch.tanh(x)
        
        
        #activating linear function
        x = self.linearfunc2(x)
        
        
        #activate tanh
        #x = torch.tanh(x)
        
        
        
        
        # log_softmax activation
        x = F.log_softmax(x, dim=1) 
        
        return x

class NetConv(nn.Module):
    # two convolutional layers and one fully connected layer,
    # all using relu, followed by log_softmax
    def __init__(self):
        super(NetConv, self).__init__()
        # INSERT CODE HERE
        
        #  creating convolution function
        self.convolution1 = nn.Conv2d(1, 11, kernel_size=3, stride = 2,padding=1)
        
        # creating convolution function
        self.convolution2 = nn.Conv2d(11, 200, kernel_size=3, stride = 2,padding=1)
        
        #creating Linear function
        self.linearfunc1= nn.Linear(800, 80)
        
        # to create Linear function
        self.linearfunc2 = nn.Linear(80,10)

    def forward(self, x):
        # activation of convulation followed by max pool followed by relu
        x = F.relu(F.max_pool2d(self.convolution1(x), 2))
        
        # activation of convulation followed by max pool followed by relu
        x = F.relu(F.max_pool2d(self.convolution2(x), 2))
        
        # flattening the data
        x = x.view(x.shape[0], -1)
        
        # activate linear function followed by relu
        x = F.relu(self.linearfunc1(x))
        
        # activate linear function
        x = self.linearfunc2(x)
        
        # log_softmax activation
        x = F.log_softmax(x, dim=1)
        
        return x

