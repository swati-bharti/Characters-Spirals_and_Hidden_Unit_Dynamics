# spiral.py
# COMP9444, CSE, UNSW

import torch
import torch.nn as nn
import matplotlib.pyplot as plt

class PolarNet(torch.nn.Module):
    def __init__(self, num_hid):
        super(PolarNet, self).__init__()
        # INSERT CODE HERE
        
        # to create Linear function
        self.linearfunc1 = nn.Linear(2,num_hid)
        
        # to create Linear function
        self.linearfunc2 = nn.Linear(num_hid,1)

    def forward(self, input):

        x = input[:,0]
        y = input[:,1]
        r=(x**2 + y**2).sqrt()
        a=torch.atan2(y,x)
        input = torch.stack([r,a],axis = -1)
       
        
         # activate linear function
         # tanh function activation
        self.hid1=torch.tanh(self.linearfunc1(input))
        
        
        
        
       
        
        # activate linear function
        # sigmoid function activation
        output = torch.sigmoid(self.linearfunc2(self.hid1))
        
        return output

class RawNet(torch.nn.Module):
    def __init__(self, num_hid):
        super(RawNet, self).__init__()
        # INSERT CODE HERE
        # to create Linear function
        self.linearfunc1 = nn.Linear(2,num_hid)
        
        # to create Linear function
        self.linearfunc2 = nn.Linear(num_hid,num_hid)
        
        # to create Linear function
        self.linearfunc3 = nn.Linear(num_hid,1)

    def forward(self, input):
        # activating linear function
        # tanh function activation
        self.hid1 = torch.tanh(self.linearfunc1(input)) 
      
        
        
        
        # activate linear function
        # tanh function activation
        self.hid2 = torch.tanh(self.linearfunc2(self.hid1))
        
       
        
        # activate linear function
        # sigmoid function activation
        output= torch.sigmoid(self.linearfunc3(self.hid2)) 
        
        
        #CHANGE CODE HERE
        return output

def graph_hidden(net, layer, node):
    xrange = torch.arange(start=-7,end=7.1,step=0.01,dtype=torch.float32)
    yrange = torch.arange(start=-6.6,end=6.7,step=0.01,dtype=torch.float32)
    xcoord = xrange.repeat(yrange.size()[0])
    ycoord = torch.repeat_interleave(yrange, xrange.size()[0], dim=0)
    grid = torch.cat((xcoord.unsqueeze(1),ycoord.unsqueeze(1)),1)

    with torch.no_grad(): 
        net.eval()        
        output = net(grid)
    if layer == 1:
        pred= (net.hid1[:,node]>=0).float()
    
    if layer == 2:
        pred= (net.hid2[:,node]>=0).float()
        

    plt.clf()
    plt.pcolormesh(xrange,yrange,pred.cpu().view(yrange.size()[0],xrange.size()[0]), cmap='Wistia')
    # INSERT CODE HERE
